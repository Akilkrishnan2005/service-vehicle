import tkinter as tk
from tkinter import font,messagebox,ttk
from PIL import Image,ImageTk,ImageFilter
import pymysql
import subprocess
import sys  
import os


def connect_db():
   return pymysql.connect(
        host="localhost",
        user="root",
        password="Akil@2005",
        database="vehicle"
    )

def login():
    Username = entry_user.get()
    Password = entry_pass.get()

    if not Username or not Password:
        messagebox.showwarning("Input Error","please enter both username and Password.")
        return

    try:
        conn = connect_db()
        cur = conn.cursor()
        cur.execute("SELECT * FROM login WHERE USERNAME=%s AND PASSWORD=%s", (Username, Password))
        result = cur.fetchone()
        conn.close()

        if result:
            messagebox.showinfo("Login Success",f"Welcome, {Username}!")
            root.destroy()
            print("login Sucessful,lanunching form_page.py...")
            subprocess.Popen([sys.executable,r"C:\DATA SCIENCE\PYTHON PROJECT\FORM PAGE.py"])

        else:
            messagebox.showerror("Login Failed","Invaild Username or Password.")
            


    except Exception as e:
        messagebox.showerror("Database error",str(e))
        print("Error during login:",e)
    
# GUI Setup
root = tk.Tk()
root.title("Login Page")
root.geometry("700x650")
img_path=Image.open(r"C:\Users\akilk\Downloads\Blue Eclipse Car-1300x650.jpg")
tk_img=ImageTk.PhotoImage(img_path)
label=tk.Label(root,image=tk_img)
label.place(x=0,y=0)

#tk.Label(root,text="LOGIN",font=("Arial",13,"bold")).pack(pady=10)

tk.Label(root, text="Username", font=('Arial', 13, 'bold')).pack(pady=10)
entry_user = tk.Entry(root, width=35)
entry_user.pack(pady=5)

tk.Label(root, text="Password", font=('Arial', 13, 'bold')).pack(pady=10)
entry_pass = tk.Entry(root, width=35, show="*")
entry_pass.pack(pady=5)

tk.Button(root, text="Login", fg="black",font=('Arial', 13, 'bold'), command=login).pack(pady=15)

root.mainloop()


